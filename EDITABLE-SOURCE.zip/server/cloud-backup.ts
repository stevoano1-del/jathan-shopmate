import{createHash,createHmac}from'node:crypto';
const hash=(x:string|Buffer)=>createHash('sha256').update(x).digest('hex');
const mac=(key:string|Buffer,value:string)=>createHmac('sha256',key).update(value).digest();
const encode=(s:string)=>encodeURIComponent(s).replace(/[!'()*]/g,c=>'%'+c.charCodeAt(0).toString(16).toUpperCase());
export function cloudConfigured(){return !!(process.env.BACKUP_ENDPOINT&&process.env.BACKUP_BUCKET&&process.env.BACKUP_ACCESS_KEY_ID&&process.env.BACKUP_SECRET_ACCESS_KEY)}
export function signS3(method:string,key:string,body=Buffer.alloc(0),now=new Date()){
 if(!cloudConfigured())throw Error('Cloud backup is not configured.');
 const endpoint=new URL(process.env.BACKUP_ENDPOINT!);const bucket=process.env.BACKUP_BUCKET!;const style=process.env.BACKUP_URL_STYLE||'virtual-host';const parts=key.split('/').map(encode).join('/');
 if(style==='path')endpoint.pathname='/'+encode(bucket)+'/'+parts;else{endpoint.hostname=bucket+'.'+endpoint.hostname;endpoint.pathname='/'+parts}endpoint.search='';
 const stamp=now.toISOString().replace(/[:-]|\.\d{3}/g,''),day=stamp.slice(0,8),region=process.env.BACKUP_REGION||'auto';const payloadHash=hash(body);const signedHeaders='host;x-amz-content-sha256;x-amz-date';
 const canonicalHeaders=`host:${endpoint.host}\nx-amz-content-sha256:${payloadHash}\nx-amz-date:${stamp}\n`;const canonical=[method,endpoint.pathname,'',canonicalHeaders,signedHeaders,payloadHash].join('\n');const scope=`${day}/${region}/s3/aws4_request`;const toSign=`AWS4-HMAC-SHA256\n${stamp}\n${scope}\n${hash(canonical)}`;const signingKey=mac(mac(mac(mac('AWS4'+process.env.BACKUP_SECRET_ACCESS_KEY!,day),region),'s3'),'aws4_request');const signature=createHmac('sha256',signingKey).update(toSign).digest('hex');
 return{url:endpoint.href,headers:{'x-amz-date':stamp,'x-amz-content-sha256':payloadHash,Authorization:`AWS4-HMAC-SHA256 Credential=${process.env.BACKUP_ACCESS_KEY_ID}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`}};
}
export async function cloudRequest(method:string,key:string,body=Buffer.alloc(0)){const signed=signS3(method,key,body);const r=await fetch(signed.url,{method,headers:signed.headers,body:['PUT','POST'].includes(method)?body:undefined,signal:AbortSignal.timeout(30000)});if(!r.ok)throw Error('Cloud backup request failed ('+r.status+').');return Buffer.from(await r.arrayBuffer())}
