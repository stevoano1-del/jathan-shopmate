import{build}from'esbuild';await build({entryPoints:['server/index.ts'],outfile:'dist/server.mjs',bundle:true,platform:'node',target:'node22',format:'esm',external:['node:*']});

await build({entryPoints:['shared/invoice.ts'],outfile:'dist/invoice.mjs',bundle:true,platform:'node',format:'esm'});
