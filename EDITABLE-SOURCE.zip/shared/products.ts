export const normal=(v:any)=>String(v??'').normalize('NFKC').trim().replace(/\s+/g,' ').toLowerCase();
export const productKey=(p:any)=>[normal(p.section),normal(p.name),normal(p.unit)].join('|');
export function sameProduct(a:any,b:any){return productKey(a)===productKey(b)||(normal(a.sku)&&normal(a.section)===normal(b.section)&&normal(a.sku)===normal(b.sku))}
export function validateProduct(a:any,sections:string[]){
 const errors:string[]=[];const name=String(a.name??'').trim(),unit=normal(a.unit)||'piece';const section=sections.find(s=>normal(s)===normal(a.section));
 if(!name||name.length>150)errors.push('Product name is required (maximum 150 characters).');if(!section)errors.push('Section does not match your business.');if(!/^[\p{L}\p{N} _-]{1,30}$/u.test(unit))errors.push('Enter a valid selling unit.');
 const numeric=(k:string)=>{const raw=a[k];const n=Number(raw);if(raw===undefined||raw===null||String(raw).trim()===''||!Number.isFinite(n)||n<0||n>1e12){errors.push(k+' must be a non-negative number.');return 0}return n};
 const quantity=numeric('quantity'),cost=numeric('cost'),price=numeric('price'),threshold=numeric('threshold');if(!['kg','g'].includes(unit)&&quantity%1)errors.push('Opening quantity must be whole items for '+unit+'.');
 const expiry=String(a.expiry||'');const expiryDate=new Date(expiry+'T00:00:00Z');if(expiry&&(!Number.isFinite(expiryDate.getTime())||!/^\d{4}-\d{2}-\d{2}$/.test(expiry)||expiryDate.toISOString().slice(0,10)!==expiry||expiry<new Date().toLocaleDateString('en-CA',{timeZone:'Africa/Lagos'})))errors.push('Expiry must be a valid date that has not passed.');
 return{errors,product:{name,section:section||String(a.section),unit,quantity,cost,price,threshold,sku:String(a.sku||'').trim(),category:String(a.category||'').trim(),expiry}};
}
export function previewProducts(rows:any[],existing:any[],sections:string[]){
 if(!Array.isArray(rows)||rows.length>1000)throw Error('Import up to 1,000 products at a time.');const accepted:any[]=[];
 const results=rows.map((row,index)=>{const checked=validateProduct(row,sections);const duplicate=!checked.errors.length&&[...existing,...accepted].some(p=>sameProduct(p,checked.product));const status=checked.errors.length?'Invalid':duplicate?'Duplicate':'Ready';if(status==='Ready')accepted.push(checked.product);return{row:index+2,status,errors:checked.errors,product:checked.product}});
 return{results,accepted,ready:accepted.length,duplicates:results.filter(x=>x.status==='Duplicate').length,invalid:results.filter(x=>x.status==='Invalid').length};
}
