export const cents=(n:number)=>Math.round((n+Number.EPSILON)*100)/100;
export function calculateReport(s:any,{section='All sections',from='',to=''}:any={}){
 const selected=(x:any)=>section==='All sections'||x.section===section;
 const inRange=(at:string)=>{const d=new Date(at).toLocaleDateString('en-CA',{timeZone:'Africa/Lagos'});return(!from||d>=from)&&(!to||d<=to)};
 let revenue=0,cost=0,returnedLoss=0;
 for(const sale of s.sales.filter((x:any)=>inRange(x.at)))for(const i of sale.items.filter(selected)){const refunds=(sale.refunds||[]).filter((r:any)=>r.product===i.product&&(r.itemIndex===undefined||r.itemIndex===sale.items.indexOf(i)));const remaining=1-(i.returned||0)/i.quantity;revenue+=i.total*remaining;cost+=(i.cost||0)*remaining;returnedLoss+=refunds.filter((r:any)=>!r.resellable).reduce((n:number,r:any)=>n+(r.cost||0),0)}
 const expenses=s.expenses.filter((e:any)=>inRange(e.at)&&selected(e));const expenseTotal=expenses.reduce((n:number,e:any)=>n+e.amount,0);const gross=revenue-cost;
 return{netSales:cents(revenue),costOfGoodsSold:cents(cost),grossProfit:cents(gross),expenses:cents(expenseTotal),nonResellableReturns:cents(returnedLoss),estimatedOperatingProfit:cents(gross-expenseTotal-returnedLoss),stockValue:cents(s.products.filter(selected).reduce((n:number,p:any)=>n+p.quantity*p.cost,0)),sharedExpensesExcluded:section!=='All sections'};
}
