import {defineConfig} from 'vite';export default defineConfig({build:{outDir:'dist/client',emptyOutDir:true},esbuild:{jsx:'automatic'}});
