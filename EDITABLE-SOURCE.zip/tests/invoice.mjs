import assert from 'node:assert/strict';
import {invoiceRows} from '../dist/invoice.mjs';
const rows=invoiceRows('Invoice 123\nPeak Milk 24 tin 650\nFrozen Chicken 20 kg 4,200\nTotal 99,000','Provisions');
assert.equal(rows.length,2);assert.equal(rows[0].quantity,'24');assert.equal(rows[0].cost,'650');assert.equal(rows[1].unit,'kg');assert.equal(rows[1].cost,'4200');assert.equal(rows[0].price,'');
const unclear=invoiceRows('Fish 20 kg 4200 84000','Frozen & Other Items');assert.equal(unclear[0].cost,'');assert.equal(unclear[0].quantity,'');
console.log('PASS: 8 invoice review checks');
